<?php
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Headers: *');
    header('Access-Control-Allow-Methods: *');

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "mixit";
    

    //variables submited by user
    $user = $_POST["username"]; 
    $threshold = $_POST["threshold"];
    $numPixels = $_POST["numPixels"];
    $time = $_POST["time"];

    $myfile = fopen("uploadFile.txt", "w") or die("Unable to open file!");


    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    if(!file_exists($_FILES['myimage']['tmp_name']) || !is_uploaded_file($_FILES['myimage']['tmp_name'])){
        echo 'No upload my image';
    }
    else{
        $img = $_FILES['myimage']['name'];
        //$tmpimg = $_FILES['myimage']['tmp_name'];
        $tmpimg = addslashes(file_get_contents($_FILES['myimage']['tmp_name']));

        echo "upload myimage";
    }

    if(!file_exists($_FILES['mybwimage']['tmp_name']) || !is_uploaded_file($_FILES['mybwimage']['tmp_name'])){
        echo 'No upload mybwimage';
    }      
    else{
        $bwimg = $_FILES['mybwimage']['name'];
       // $bwtmpimg = $_FILES['mybwimage']['tmp_name'];
       $bwtmpimg = addslashes(file_get_contents($_FILES['mybwimage']['tmp_name']));
        echo "upload mybwimage";
    } 


    $sql = "INSERT INTO customlevels (username , threshold, colorImg, bwImg, numberPixels, timeInSec)
   VALUES ( '" . $user ."' , $threshold, '{$tmpimg}' , '{$bwtmpimg}', $numPixels, $time)"; 
    

    if ($conn->query($sql) === TRUE) {
        //echo "New images uploaded successfully";
//         $sql = "SELECT MAX(level) AS max_level FROM customlevels"// WHERE username= '" . $user ."'";
//         $result = $conn->query($sql);
//         if ($result->num_rows > 0) {

//             $row = $result->fetch_assoc();
//             echo "baini";
//         }
    } 
    else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    //echo "[success] image ($img) uploaded successfully";
    exit();
    

    

    $conn->close();

?>