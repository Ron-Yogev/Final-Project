<?php
    header('Access-Control-Allow-Origin: *');

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "mixit";

    //variables submited by user
    $level = $_POST["level"]; 
    $isBW = $_POST["isBW"];

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // $sql = "SELECT colorImg FROM levels WHERE level = 15";
    // $result = $conn->query($sql);
    // $row = $result->fetch_assoc();
    // echo json_encode($row);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }


    if($isBW == 1){
        $imgStr = "bwImg";
        $sql = "SELECT bwImg FROM customlevels WHERE level = $level";
    }
    else{
        $imgStr = "colorImg";
        $sql = "SELECT colorImg FROM customlevels WHERE level = $level";
    }

    

    // $path = "http://localhost/UnityBackend/uploaded_images/bwimagefronUnity.png";

    // $img = file_get_contents($path);
    // echo $img;

    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        // $image = file_get_contents()
        header("Content-type: image/png");
        echo $row[$imgStr];
        echo "retrieve successfully";
    }
    else {
      echo "There is no result image to level = $level."; 
    }
    $conn->close();

?>