<?php
    header('Access-Control-Allow-Origin: *');

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "mixit";

    //variables submited by user
    $loginUser = $_POST["loginUser"]; 
    $loginPass = $_POST["loginPass"];

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "SELECT * FROM users WHERE username = '" . $loginUser ."'";

    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        // echo "password: " . $row["password"]. "";
        if($row["password"] == $loginPass){
            echo $row["level"];
            //echo "Login Success.";

            
        }
        else{
            echo "Wrong Credentials.";
        }
        
    } 
    else {
      echo "Username dosent exist."; 
    }
    $conn->close();

?>