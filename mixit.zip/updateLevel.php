<?php

    header('Access-Control-Allow-Origin: *');

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "mixit";

    $user = $_POST["user"];
    //$level = $_POST["level"];

    // $nextLevel = $level +1;



    // SET @userlvel = (SELECT level FROM users WHERE username = 'ron1112');
    // UPDATE users SET level = @userlvel +1 WHERE username='ron1112'
    echo "Beforeeee in php";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
    }

    $sql1 = "SET @userlvel = (SELECT level FROM users WHERE username = '" . $user ."')";
    

    $sql2 = "UPDATE users SET level = @userlvel +1 WHERE username= '" . $user ."'";

    if($conn->query($sql1) === TRUE){
        echo "sql1  successfully";
    }
    else {
        echo "Error updating sql1: " . $conn->error;
        }

    if ($conn->query($sql2) === TRUE) {
    echo "sql2 successfully";
    } else {
    echo "Error updating sql2: " . $conn->error;
    }

    $conn->close();
?>