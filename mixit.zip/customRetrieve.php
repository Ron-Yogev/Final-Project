<?php
    header('Access-Control-Allow-Origin: *');
    error_reporting(E_ALL);
    $myfile = fopen("customFile.txt", "w") or die("Unable to open file!");

    $txt = "before connection\n";
    fwrite($myfile, $txt);

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "mixit";

    //variables submited by user
    $level = $_POST["level"]; 
    $isBW = $_POST["isBW"];

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // $sql = "SELECT colorImg FROM levels WHERE level = 15";
    // $result = $conn->query($sql);
    // $row = $result->fetch_assoc();
    // echo json_encode($row);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $txt = "after connection\n";
    fwrite($myfile, $txt);

    $sql = "SELECT MAX(level) AS max_level FROM customlevels";

    $txt = "sql query = " . $sql . "\n";
    fwrite($myfile, $txt);

    $result = $conn->query($sql);

    // $txt = "result = " . . "\n";
    // fwrite($myfile, $txt);

    $maxLevel = 0;
    if ($result->num_rows > 0) {

        $row = $result->fetch_assoc();
        $txt = "row = " . $row . "\n";
        fwrite($myfile, $txt);
        $maxLevel = $row["max_level"];
    }
    echo $maxLevel;
    $txt = "after maxLevel =" . $maxLevel . "\n";
    fwrite($myfile, $txt);

    if($isBW == 1){
        $txt = "in isBW\n";
        fwrite($myfile, $txt);
        $imgStr = "bwImg";
        $sql = "SELECT bwImg FROM customlevels WHERE level = $maxLevel";
        $txt = "sql query = " . $sql . "\n";
        fwrite($myfile, $txt);
        // $sql = "SELECT bwImg FROM customlevels WHERE level IN ( SELECT MAX(level) FROM customlevels)";
        // $sql = "SELECT bwImg FROM customlevels WHERE level IN (SELECT MAX(level) FROM customlevels)";
    }
    else{
        $imgStr = "colorImg";
        // $sql = "SELECT colorImg FROM customlevels WHERE level IN (SELECT MAX(level) FROM customlevels)";
        // $sql = "SELECT colorImg FROM customlevels WHERE level IN (SELECT MAX(level) FROM customlevels)";
        $sql = "SELECT colorImg FROM customlevels WHERE level = $maxLevel";
        
    }

    // $path = "http://localhost/UnityBackend/uploaded_images/bwimagefronUnity.png";

    // $img = file_get_contents($path);
    // echo $img;

    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        
        $row = $result->fetch_assoc();
        $txt = "row = " . $row . "\n";
        fwrite($myfile, $txt);
        // $image = file_get_contents()
        header('Content-Type: image/png');
        echo $row[$imgStr];
        echo "retrieve successfully";
    }
    else {
      echo "There is no result image to level = $level."; 
    }
    fclose($myfile);
    $conn->close();

?>