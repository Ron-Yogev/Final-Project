<?php

    header('Access-Control-Allow-Origin: *');

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "mixit";

    //variables submited by user
    $loginUser = $_POST["registerUser"]; 
    $loginPass = $_POST["registerPass"];

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "SELECT username FROM users WHERE username = '" . $loginUser ."'";

    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        //Tell user that name is already exist
        echo "Username is already taken.";
        
        
    } 
    else{
        echo "Creating user...";

        //Insert the user and password into the database

        $sql2 = "INSERT INTO users (username, password, level, customLevel)
                VALUES ('" . $loginUser ."', '" . $loginPass . "', 1, 0)";

        if ($conn->query($sql2) === TRUE) {
            echo "New record created successfully";
        } 
        else {
            echo "Error: " . $sql2 . "<br>" . $conn->error;
        }
    }

    $conn->close();

?>