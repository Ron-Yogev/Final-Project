<?php

    header('Access-Control-Allow-Origin: *');


    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "mixit";


    $conn = new mysqli($servername, $username, $password, $dbname);
    
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }


    $sql = "SELECT MAX(level) AS max_level FROM customlevels";// WHERE username= '" . $user ."'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {

        $row = $result->fetch_assoc();
        if($row["max_level"] != ""){
            echo $row["max_level"];

        }
        else{
            echo "not found";
        }
    }


?>