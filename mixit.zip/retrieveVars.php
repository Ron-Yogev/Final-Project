<?php
    header('Access-Control-Allow-Origin: *');

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "mixit";

    //variables submited by user
    $level = $_POST["level"]; 

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "SELECT threshold,numberPixels,timeInSec FROM levels WHERE level = $level";

    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        // echo "password: " . $row["password"]. "";
        echo "${row["threshold"]},${row["numberPixels"]},${row["timeInSec"]}";

        
    } 

    $conn->close();

?>